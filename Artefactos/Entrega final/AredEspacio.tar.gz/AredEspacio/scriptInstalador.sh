#!/bin/bash
dirscript=$(readlink -f $0)
dirbase=`dirname $dirscript`

su -l $2 -c 'mkdir '$1'/AredEspacio 2> /dev/null'
su -l $2 -c 'cp -r '$dirbase'/AredEspacio/ '$1

var=$1"/AredEspacio"

su -l $2 -c 'echo "#!/bin/bash
java -jar "'$var'"/AredEspacio.jar" >> '$var'"/"aredespacio.sh'
mysql -u $3 -p < $dirbase/AredEspacio/aredScript.sql

echo "[Desktop Entry]
Name=Ared espacio
Comment=Versión final del proyecto AredEspacio para la EE Desarrollo de software
Exec="$var"/aredespacio.sh
Icon="$var"/LogoAred2.ico
Terminal=false
Type=Application
" >> /usr/share/applications/aredespacio.desktop

chmod 755 $var"/"aredespacio.sh
chmod 755 $var
